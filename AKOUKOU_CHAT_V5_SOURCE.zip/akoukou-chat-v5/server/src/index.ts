import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import cors from 'cors';
import helmet from 'helmet';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'node:crypto';
import { Server } from 'socket.io';
import { AccessToken } from 'livekit-server-sdk';
import { z } from 'zod';
import { db } from './db.js';

const app = express();
const server = http.createServer(app);
const origin = process.env.CLIENT_ORIGIN || 'http://localhost:5173';
const io = new Server(server, { cors: { origin, methods: ['GET','POST'] } });
const secret = process.env.JWT_SECRET;
if (!secret || secret.length < 32) console.warn('WARNING: Set JWT_SECRET to a random secret of at least 32 characters.');
const JWT_SECRET = secret || 'development-only-change-this-secret-123456';
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin })); app.use(express.json({ limit: '1mb' }));

function sign(user: {id:string; phone:string; display_name:string}) { return jwt.sign({ sub:user.id, phone:user.phone, name:user.display_name }, JWT_SECRET, { expiresIn:'14d' }); }
function auth(req:any,res:any,next:any) {
 const h = req.headers.authorization || ''; const token = h.startsWith('Bearer ') ? h.slice(7) : '';
 try { req.user = jwt.verify(token, JWT_SECRET) as any; next(); } catch { res.status(401).json({error:'Session invalide. Reconnectez-vous.'}); }
}
function isMember(conversationId:string,userId:string) { return !!db.prepare('SELECT 1 FROM members WHERE conversation_id=? AND user_id=?').get(conversationId,userId); }
app.get('/api/health', (_req,res)=>res.json({ok:true,app:'AKOUKOU CHAT',version:'5.0.0'}));

app.post('/api/auth/register', async (req,res) => {
 const parsed = z.object({displayName:z.string().min(2).max(60),phone:z.string().min(7).max(20),password:z.string().min(8).max(100)}).safeParse(req.body);
 if(!parsed.success) return res.status(400).json({error:'Nom, numéro et mot de passe (8 caractères minimum) requis.'});
 const {displayName,phone,password}=parsed.data; const exists=db.prepare('SELECT id FROM users WHERE phone=?').get(phone);
 if(exists) return res.status(409).json({error:'Ce numéro est déjà inscrit.'});
 const user={id:randomUUID(),display_name:displayName,phone};
 db.prepare('INSERT INTO users(id,display_name,phone,password_hash) VALUES(?,?,?,?)').run(user.id,user.display_name,user.phone,await bcrypt.hash(password,12));
 res.status(201).json({token:sign(user),user:{id:user.id,displayName:user.display_name,phone:user.phone}});
});
app.post('/api/auth/login', async (req,res) => {
 const parsed=z.object({phone:z.string(),password:z.string()}).safeParse(req.body); if(!parsed.success)return res.status(400).json({error:'Numéro et mot de passe requis.'});
 const user:any=db.prepare('SELECT * FROM users WHERE phone=?').get(parsed.data.phone);
 if(!user || !(await bcrypt.compare(parsed.data.password,user.password_hash))) return res.status(401).json({error:'Numéro ou mot de passe incorrect.'});
 res.json({token:sign(user),user:{id:user.id,displayName:user.display_name,phone:user.phone}});
});
app.get('/api/me',auth,(req:any,res)=>{const u:any=db.prepare('SELECT id,display_name AS displayName,phone FROM users WHERE id=?').get(req.user.sub);res.json({user:u});});
app.get('/api/users',auth,(req:any,res)=>{const q=String(req.query.q||'').slice(0,60);const rows=db.prepare('SELECT id,display_name AS displayName,phone FROM users WHERE id<>? AND (display_name LIKE ? OR phone LIKE ?) ORDER BY display_name LIMIT 30').all(req.user.sub,`%${q}%`,`%${q}%`);res.json({users:rows});});
app.post('/api/conversations/direct',auth,(req:any,res)=>{
 const parsed=z.object({userId:z.string()}).safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'Contact invalide.'});
 const other=db.prepare('SELECT id FROM users WHERE id=?').get(parsed.data.userId);if(!other)return res.status(404).json({error:'Utilisateur introuvable.'});
 const existing=db.prepare(`SELECT c.id FROM conversations c JOIN members a ON a.conversation_id=c.id JOIN members b ON b.conversation_id=c.id WHERE c.is_group=0 AND a.user_id=? AND b.user_id=?`).get(req.user.sub,parsed.data.userId) as any;
 if(existing)return res.json({conversationId:existing.id});
 const id=randomUUID();db.prepare('INSERT INTO conversations(id,is_group) VALUES(?,0)').run(id);const add=db.prepare('INSERT INTO members(conversation_id,user_id) VALUES(?,?)');add.run(id,req.user.sub);add.run(id,parsed.data.userId);res.status(201).json({conversationId:id});
});
app.get('/api/conversations',auth,(req:any,res)=>{
 const rows=db.prepare(`SELECT c.id,c.title,c.is_group AS isGroup,c.created_at AS createdAt,
 (SELECT body FROM messages WHERE conversation_id=c.id ORDER BY created_at DESC LIMIT 1) AS lastMessage,
 (SELECT display_name FROM users u JOIN members m ON m.user_id=u.id WHERE m.conversation_id=c.id AND u.id<>? LIMIT 1) AS contactName,
 (SELECT u.id FROM users u JOIN members m ON m.user_id=u.id WHERE m.conversation_id=c.id AND u.id<>? LIMIT 1) AS contactId
 FROM conversations c JOIN members me ON me.conversation_id=c.id WHERE me.user_id=? ORDER BY COALESCE((SELECT created_at FROM messages WHERE conversation_id=c.id ORDER BY created_at DESC LIMIT 1),c.created_at) DESC`).all(req.user.sub,req.user.sub,req.user.sub);
 res.json({conversations:rows});
});
app.get('/api/conversations/:id/messages',auth,(req:any,res)=>{if(!isMember(req.params.id,req.user.sub))return res.sendStatus(403);const rows=db.prepare('SELECT id,sender_id AS senderId,body,kind,created_at AS createdAt FROM messages WHERE conversation_id=? ORDER BY created_at DESC LIMIT 100').all(req.params.id).reverse();res.json({messages:rows});});
app.post('/api/conversations/:id/messages',auth,(req:any,res)=>{
 if(!isMember(req.params.id,req.user.sub))return res.sendStatus(403);const parsed=z.object({body:z.string().min(1).max(4000),kind:z.enum(['text','voice','image','file']).default('text')}).safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'Message invalide.'});
 const msg={id:randomUUID(),conversationId:req.params.id,senderId:req.user.sub,body:parsed.data.body,kind:parsed.data.kind,createdAt:new Date().toISOString()};db.prepare('INSERT INTO messages(id,conversation_id,sender_id,body,kind) VALUES(?,?,?,?,?)').run(msg.id,msg.conversationId,msg.senderId,msg.body,msg.kind);io.to(`conversation:${msg.conversationId}`).emit('message:new',msg);res.status(201).json({message:msg});
});
app.post('/api/calls/token',auth,async(req:any,res)=>{
 const parsed=z.object({roomName:z.string().min(1).max(100)}).safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'Salon d’appel invalide.'});
 const {LIVEKIT_URL,LIVEKIT_API_KEY,LIVEKIT_API_SECRET}=process.env;if(!LIVEKIT_URL||!LIVEKIT_API_KEY||!LIVEKIT_API_SECRET)return res.status(503).json({error:'Les appels ne sont pas encore configurés. Le propriétaire doit renseigner les clés LiveKit.'});
 const at=new AccessToken(LIVEKIT_API_KEY,LIVEKIT_API_SECRET,{identity:req.user.sub,name:req.user.name,ttl:'1h'});at.addGrant({roomJoin:true,room:parsed.data.roomName,canPublish:true,canSubscribe:true});res.json({url:LIVEKIT_URL,token:await at.toJwt()});
});

io.use((socket,next)=>{try{const token=socket.handshake.auth?.token;const decoded=jwt.verify(token,JWT_SECRET) as any;(socket as any).user=decoded;next();}catch{next(new Error('unauthorized'));}});
io.on('connection',(socket)=>{
 const user=(socket as any).user;socket.join(`user:${user.sub}`);
 socket.on('conversation:join',(id:string)=>{if(typeof id==='string'&&isMember(id,user.sub))socket.join(`conversation:${id}`);});
 socket.on('call:invite',(payload:any)=>{if(!payload||typeof payload.toUserId!=='string'||typeof payload.roomName!=='string')return;io.to(`user:${payload.toUserId}`).emit('call:incoming',{fromUserId:user.sub,fromName:user.name,roomName:payload.roomName,mode:payload.mode==='video'?'video':'audio'});});
 socket.on('call:decline',(payload:any)=>{if(payload?.toUserId&&payload?.roomName)io.to(`user:${payload.toUserId}`).emit('call:declined',{roomName:payload.roomName});});
 socket.on('call:end',(payload:any)=>{if(payload?.toUserId&&payload?.roomName)io.to(`user:${payload.toUserId}`).emit('call:ended',{roomName:payload.roomName});});
});
const port=Number(process.env.PORT||4000);server.listen(port,()=>console.log(`AKOUKOU CHAT V5 API listening on :${port}`));
