# AKOUKOU CHAT V5 — base technique

Nouvelle base indépendante pour une application de messagerie Android/Web : comptes par numéro + mot de passe, contacts/recherche, conversations privées, messages temps réel (Socket.IO), appels audio/vidéo (LiveKit), interface PWA installable.

## Important — état réel du livrable

Ce dossier est un **prototype full-stack / socle de développement**, pas encore une application publiée ni un service hébergé. Les appels ne fonctionneront qu'après configuration d'un serveur LiveKit et des clés côté serveur. Les notifications lorsque l'application est fermée, le chiffrement de bout en bout, les groupes complets, l'envoi réel de fichiers, la modération et la migration des données V4 restent à développer/valider avant une mise en production.

La base V4 n'a pas été retrouvée : aucune conversation ni aucun compte V4 n'est importé dans ce projet. Ne désinstallez pas V4 et conservez ses données.

## Prérequis

- Node.js 20 ou supérieur
- npm 10 ou supérieur
- Un serveur/VPS ou hébergement Node pour le backend
- Un compte LiveKit Cloud (ou serveur LiveKit) pour les appels audio/vidéo
- HTTPS en production (obligatoire pour caméra/micro et PWA)

## Installation locale

1. Copier `.env.example` vers `.env` à la racine.
2. Remplacer `JWT_SECRET` par une longue valeur aléatoire.
3. Dans `.env`, renseigner `LIVEKIT_URL`, `LIVEKIT_API_KEY` et `LIVEKIT_API_SECRET` depuis le tableau de bord LiveKit. Ne jamais mettre ces secrets dans le code client.
4. Installer les dépendances : `npm install`.
5. Démarrer : `npm run dev`.
6. Ouvrir `http://localhost:5173`.

Le backend écoute sur `http://localhost:4000` et crée sa base SQLite dans `server/data/`.

## Déploiement

- Déployer `server` sur un hébergeur Node avec disque persistant pour SQLite (ou remplacer SQLite par PostgreSQL pour plusieurs instances).
- Définir les variables d'environnement du serveur.
- Déployer `client` comme site statique HTTPS et définir `VITE_API_URL` à l'URL HTTPS du backend avant le build.
- Définir `CLIENT_ORIGIN` sur l'origine HTTPS exacte du frontend.
- Configurer un domaine, sauvegardes, supervision, limites anti-abus et politique de confidentialité.

## Android

Le client est une PWA responsive qui peut être installée depuis Chrome sur Android (menu ⋮ → Installer l'application / Ajouter à l'écran d'accueil). Pour une publication Google Play, il faudra ensuite créer et signer un paquet Android (par exemple avec Capacitor), ajouter les permissions caméra/micro/notifications et tester les appels en arrière-plan sur plusieurs appareils.

## Sécurité et production — indispensables

- HTTPS partout, secrets forts et sauvegardes chiffrées.
- Rate limiting, validation, protection contre l'inscription automatisée et récupération de compte.
- Politique de confidentialité et consentement pour contacts, caméra, micro et notifications.
- Stockage privé des médias avec URLs signées; ne pas stocker de fichiers sensibles dans SQLite.
- Chiffrement de bout en bout non inclus dans ce prototype. Ne pas présenter les messages comme chiffrés de bout en bout.
- Les notifications push Android lorsque l'application est fermée nécessitent Firebase Cloud Messaging et une configuration native supplémentaire.
- Les appels nécessitent une configuration LiveKit/TURN et des essais sur réseaux mobiles/Wi-Fi au Niger.
