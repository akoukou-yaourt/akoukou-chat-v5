# AKOUKOU CHAT V5 — Plan de développement (budget initial : 0 FCFA)

## Objectif
Construire une messagerie Android/Web sous la marque AKOUKOU CHAT, en gardant l'identité verte de V4. La V5 est un nouveau projet indépendant : aucune donnée V4 n'est actuellement migrée.

## État actuel du dossier
Le ZIP contient un socle React/Vite côté client et Express/SQLite/Socket.IO côté serveur. Il comprend une inscription/connexion par numéro et mot de passe, la recherche d'utilisateurs, les conversations privées, les messages texte, et un premier branchement LiveKit pour les appels. Ce socle n'est pas un service public hébergé et n'est pas prêt pour une publication.

Fonctions encore incomplètes ou à valider :
- sécurisation complète des invitations et des salons d'appel ;
- groupes (création, membres, rôles, messages) ;
- envoi et stockage réel des images, fichiers et notes vocales ;
- notifications push lorsque l'application est fermée ;
- récupération de compte et vérification de numéro ;
- chiffrement de bout en bout ;
- modération, signalement, blocage et anti-spam ;
- sauvegardes, supervision, tests sur réseau mobile et publication Android.

## Plan par étapes

### Étape 1 — Préparer l'environnement (sans frais logiciels)
1. Conserver l'APK V4 et ne pas effacer ses données.
2. Décompresser `AKOUKOU_CHAT_V5_SOURCE.zip` sur un ordinateur.
3. Installer Node.js 20+ et npm 10+.
4. Dans le dossier du projet, copier `.env.example` vers `.env`.
5. Générer un secret JWT long et aléatoire. Ne jamais partager le fichier `.env`.
6. Installer les dépendances avec `npm install`, puis lancer `npm run dev`.
7. Vérifier l'interface sur `http://localhost:5173` et l'API sur `http://localhost:4000/api/health`.

### Étape 2 — Valider la messagerie de base
- Tester inscription, connexion et déconnexion.
- Créer deux comptes de test avec deux numéros contrôlés par le propriétaire.
- Tester recherche de contacts, conversation privée et messages dans les deux sens.
- Corriger les erreurs et ajouter les tests automatisés avant toute mise en ligne.

### Étape 3 — Rendre les appels audio/vidéo sûrs
- Créer un compte LiveKit Cloud ou déployer un serveur LiveKit (un compte/serveur et des identifiants sont nécessaires ; vérifier les quotas et conditions gratuits en vigueur).
- Garder les clés LiveKit uniquement dans les variables secrètes du serveur, jamais dans le navigateur.
- Faire émettre les invitations par le serveur après vérification que l'appelant et le destinataire appartiennent à la conversation.
- Limiter les salons et jetons à la conversation et à la durée de l'appel ; gérer refus, absence de réponse, raccrochage et reconnexion.
- Tester audio seul, vidéo, autorisations caméra/micro, Wi-Fi et données mobiles sur deux appareils.

### Étape 4 — Compléter les fonctions essentielles
- Groupes : créer, renommer, ajouter/retirer des membres et définir les rôles.
- Médias : téléversement vers un stockage privé, limites de taille et liens temporaires.
- Notes vocales : enregistrement, lecture, durée et suppression.
- Sécurité : récupération de compte, blocage/signalement, limitation des tentatives et journalisation minimale.
- Chiffrement : concevoir et auditer le chiffrement de bout en bout avant de le présenter comme disponible.

### Étape 5 — Notifications et Android
- Configurer Firebase Cloud Messaging pour les notifications push ; les notifications quand l'application est fermée ne sont pas fournies par la seule page Web.
- Ajouter une enveloppe Android (par exemple Capacitor), les permissions caméra/micro et le traitement des appels entrants.
- Tester les notifications et appels en arrière-plan sur plusieurs versions Android.
- Générer une version Android signée avec une clé de production conservée en lieu sûr.

### Étape 6 — Mise en ligne et publication
- Déployer le serveur Node avec stockage persistant (SQLite pour un prototype mono-instance ; PostgreSQL recommandé si montée en charge).
- Héberger le client en HTTPS et configurer le domaine, CORS, sauvegardes et surveillance.
- Rédiger politique de confidentialité, conditions d'utilisation et procédure de suppression de compte.
- Effectuer un audit de sécurité et des tests de charge ; ensuite seulement préparer Google Play.

## Ce que signifie « 0 FCFA »
Le développement local peut commencer avec des outils gratuits. En revanche, une messagerie publique avec disponibilité permanente, appels audio/vidéo, stockage des médias, notifications et domaine peut entraîner des coûts ou des limites de quotas. Les offres gratuites peuvent changer, dormir ou limiter le trafic. Ne promettre aucun appel « gratuit et illimité » avant d'avoir vérifié les conditions du fournisseur et testé la qualité au Niger.

## Informations et accès nécessaires au moment du déploiement
- Un ordinateur pour installer et lancer le projet (ou un environnement cloud de développement compatible).
- Un compte LiveKit pour les appels.
- Un projet Firebase pour les notifications Android.
- Un hébergeur compatible Node et un stockage persistant pour le serveur.
- Un domaine HTTPS pour un service public stable.
- L'accès à l'ancienne base V4 uniquement si une migration des comptes/messages est souhaitée et techniquement possible.

## Règles de sécurité
- Ne jamais envoyer de mot de passe, clé API, secret JWT, clé LiveKit ou fichier `.env` dans une conversation.
- Ne pas publier la V5 avec des comptes réels avant audit et sauvegardes.
- Ne pas désinstaller V4 tant que les données utiles ne sont pas sauvegardées.
- Ne pas annoncer le chiffrement de bout en bout tant qu'il n'est pas effectivement développé et audité.
